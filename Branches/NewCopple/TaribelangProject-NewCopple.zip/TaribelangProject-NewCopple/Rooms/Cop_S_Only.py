from GameFrame import Level, TextObject, Globals, EnumLevels


class Cop_S_Only(Level):
    def __init__(self, screen, joysticks):
        Level.__init__(self, screen, joysticks)

        room_name = TextObject(self, 200, 300, "Copple Story Only", colour=(255, 255, 255))
        self.add_room_object(room_name)

        self.set_timer(60, self.complete)

    def complete(self):
        Globals.direct_select = True
        Globals.next_level = EnumLevels.Cop_S1
        self.running = False
