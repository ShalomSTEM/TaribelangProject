from GameFrame import Story, Globals, EnumLevels

class Cop_S4(Story):
    def __init__(self, screen, joysticks):
        Story.__init__(self, screen, joysticks, "Copple_4.wav", 'Copple Story', "Cop_Background_4.png")
        self.set_timer(930, self.complete)


    def complete(self):
        if Globals.direct_select:
            Globals.direct_select = False
            Globals.next_level = EnumLevels.Home
        self.running = False
